package com.example.carfinance;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.jetbrains.annotations.NotNull;

public class CustomerRegister extends AppCompatActivity {
EditText name,email,password,phone;
Button signup;
FirebaseAuth mAuth;
FirebaseDatabase firebaseDatabase;
DatabaseReference databaseReference;
ProgressBar progBar;
    private SignInButton signInButton;
    private GoogleSignInClient googleSignInClient;
    private String TAG="mainTag";
    private int RESULT_CODE_SINGIN=999;
//    Customer_model customer_model=new Customer_model();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_register);

        mAuth=FirebaseAuth.getInstance();
        signInButton = findViewById(R.id.SignIn_Button);
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("Customer_Signup");
        progBar=findViewById(R.id.progress);
        name=findViewById(R.id.name);
        email=findViewById(R.id.email);
        password=findViewById(R.id.password);
        phone=findViewById(R.id.phone);
        signup=findViewById(R.id.signup);
        progBar.setVisibility(View.INVISIBLE);
        GoogleSignInOptions gso = new
                GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
//                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        googleSignInClient = GoogleSignIn.getClient(this,gso);

        //Attach a onClickListener
        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signInM();
            }
        });

    }
    //when the signIn Button is clicked then start the signIn Intent
    private void signInM() {
        Intent singInIntent = googleSignInClient.getSignInIntent();
        startActivityForResult(singInIntent,RESULT_CODE_SINGIN);
    }

    // onActivityResult (Here we handle the result of the Activity )
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RESULT_CODE_SINGIN) {        //just to verify the code
            //create a Task object and use GoogleSignInAccount from Intent and write a separate method to handle singIn Result.

            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult(task);
        }
    }


    private void handleSignInResult(Task<GoogleSignInAccount> task) {

        //we use try catch block because of Exception.
        try {
            signInButton.setVisibility(View.INVISIBLE);
            GoogleSignInAccount account = task.getResult(ApiException.class);
            Toast.makeText(CustomerRegister.this,"Signed In successfully",Toast.LENGTH_LONG).show();
            Snackbar.make(findViewById(android.R.id.content),"Google SignIn Successfully",Snackbar.LENGTH_LONG);

            FirebaseGoogleAuth(account);

        } catch (ApiException e) {
            e.printStackTrace();
            Log.w(TAG, "signInResult:failed code=" + e.getStatusCode());
            Toast.makeText(CustomerRegister.this,"SignIn Failed!!!",Toast.LENGTH_LONG).show();
            FirebaseGoogleAuth(null);
        }
    }

    private void FirebaseGoogleAuth(GoogleSignInAccount account) {
        AuthCredential credential = GoogleAuthProvider.getCredential(account.getIdToken(), null);
        //here we are checking the Authentication Credential and checking the task is successful or not and display the message
        //based on that.
        mAuth.signInWithCredential(credential).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()){
                    Toast.makeText(CustomerRegister.this,"successful",Toast.LENGTH_LONG).show();
                    FirebaseUser firebaseUser = mAuth.getCurrentUser();
                    UpdateUI(firebaseUser);
                    Intent intent=new Intent(getApplicationContext(),MainActivity.class);
                }
                else {
                    Toast.makeText(CustomerRegister.this,"Failed!",Toast.LENGTH_LONG).show();
                    UpdateUI(null);
                }
            }
        });
    }

    //Inside UpdateUI we can get the user information and display it when required
    private void UpdateUI(FirebaseUser fUser) {

        //getLastSignedInAccount returned the account
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(getApplicationContext());
        if (account != null) {
            String personName = account.getDisplayName();
            String personGivenName = account.getGivenName();
            String personEmail = account.getEmail();
            String personId = account.getId();

            Toast.makeText(CustomerRegister.this, personName + "  " + personEmail, Toast.LENGTH_LONG).show();
        }
    }
        public void RegisterUser(View view){

                final String u_name=name.getText().toString();
                final String u_email=email.getText().toString();
                final String u_pass=password.getText().toString();
                final String u_phone=phone.getText().toString();

                if (u_name.isEmpty()){
                    name.setError("Name Is Required");
                    name.requestFocus();
                    return;
                }

                if (u_email.isEmpty()){
                    email.setError("Email Is Required");
                    email.requestFocus();
                    return;
                }
                if (u_pass.isEmpty()){
                    password.setError("Password Is Required");
                    password.requestFocus();
                    return;
                }
                if (u_phone.isEmpty()){
                    phone.setError("Phone Number Is Required");
                    phone.requestFocus();
                    return;
               }
              if (!Patterns.EMAIL_ADDRESS.matcher(u_email).matches()){
                    email.setError("Invalid Email Address");
                 email.requestFocus();
                    return;
                }


       progBar.setVisibility(View.VISIBLE);
                mAuth.createUserWithEmailAndPassword(u_email, u_pass)
                        .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    Customer_model customer_model=new Customer_model(
                                            u_name,
                                            u_phone,
                                            u_email

                                    );
                                 FirebaseDatabase.getInstance().getReference("Customer_Signup")
                                         .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                         .setValue(customer_model).addOnCompleteListener(new OnCompleteListener<Void>() {
                                     @Override
                                     public void onComplete(@NonNull @NotNull Task<Void> task) {
                                         progBar.setVisibility(View.GONE);

                                         if (task.isSuccessful()){
                                             progBar.setVisibility(View.INVISIBLE);
                                         }else{
                                             Toast.makeText(CustomerRegister.this, "Failed", Toast.LENGTH_SHORT).show();
                                         }
                                     }
                                 });

                                    Toast.makeText(CustomerRegister.this, "You Have Signed Up Successfully", Toast.LENGTH_SHORT).show();


                                } else {
                                    Toast.makeText(CustomerRegister.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        });

    }

//    private void CustomerRedirect() {
//        Intent intent=new Intent(getApplicationContext(),MainActivity.class);
//        startActivity(intent);
//    }



}