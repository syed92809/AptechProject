package com.example.carfinance;

public class Customer_model {

    String u_name,u_phone,u_email;

    public Customer_model() {
    }

    public Customer_model(String u_name, String u_phone, String u_email) {
        this.u_name = u_name;
        this.u_phone = u_phone;
        this.u_email = u_email;
    }
}

